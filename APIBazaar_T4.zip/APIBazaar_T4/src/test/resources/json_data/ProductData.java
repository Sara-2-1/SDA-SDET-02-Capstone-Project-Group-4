package json_data;

public class ProductData {
    public final static String Product_Data= """
        {
            "name":"Camera Nikon",
                "price":1500,
                "stock":100,
                "sku":"101010",
                "category_id":1,
                "manufacturer":"Manufacturer Name",
                "image_url":"images/image123.jpg",
                "discount":0.1,
                "description":"Product description"
        }
    """;
}
